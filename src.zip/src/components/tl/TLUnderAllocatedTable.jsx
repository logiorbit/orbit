import { useEffect, useState } from "react";
import { useMsal } from "@azure/msal-react";
import { getAccessToken } from "../../auth/authService";
import { getTasksForDate } from "../../services/sharePointService";
import { useUserContext } from "../../context/UserContext";
import DataTable from "../common/DataTable";

export default function TLUnderAllocatedTable() {
  const { instance, accounts } = useMsal();
  const { employeeHierarchy, userProfile } = useUserContext();

  const [rows, setRows] = useState([]);

  useEffect(() => {
    if (!employeeHierarchy || !userProfile || !accounts?.length) return;

    async function load() {
      const token = await getAccessToken(instance, accounts[0]);

      const today = new Date().toISOString().split("T")[0];
      const tasks = await getTasksForDate(token, today);

      const myEmail = userProfile.email.toLowerCase();

      // Filter only my team
      const myTeam = employeeHierarchy.filter(
        (h) =>
          h.TL?.EMail?.toLowerCase() === myEmail ||
          h.ATL?.EMail?.toLowerCase() === myEmail
      );

      // Aggregate hours per employee
      const allocationMap = {};

      tasks.forEach((t) => {
        const email = t.Employee?.EMail?.toLowerCase();
        if (!email) return;

        const isMyMember = myTeam.some(
          (m) => m.Employee?.EMail?.toLowerCase() === email
        );
        if (!isMyMember) return;

        allocationMap[email] =
          (allocationMap[email] || 0) + (t.EstimatedHours || 0);
      });

      // Build rows (< 9 hours)
      const result = Object.entries(allocationMap)
        .filter(([_, hrs]) => hrs < 9)
        .map(([email, hrs]) => {
          const emp = myTeam.find(
            (m) => m.Employee?.EMail?.toLowerCase() === email
          );

          return {
            Id: email,
            Employee: emp?.Employee?.Title || email,
            Allocated: hrs.toFixed(1),
            Capacity: "9.0",
            Gap: (9 - hrs).toFixed(1),
          };
        });

      setRows(result);
    }

    load();
  }, [employeeHierarchy, userProfile, accounts]);

  const columns = [
    { key: "Employee", label: "Employee" },
    { key: "Allocated", label: "Allocated (hrs)" },
    { key: "Capacity", label: "Capacity" },
    { key: "Gap", label: "Remaining (hrs)" },
  ];

  return <DataTable columns={columns} data={rows} />;
}
