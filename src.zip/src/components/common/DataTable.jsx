import StatusBadge from "./StatusBadge";
import "./table.css";

export default function DataTable({ columns, data = [], renderActions }) {
  return (
    <div className="table-card">
      <table className="data-table">
        <thead>
          <tr>
            {columns.map((col) => (
              <th key={col.key}>{col.label}</th>
            ))}
            {renderActions && <th />}
          </tr>
        </thead>

        <tbody>
          {data.length === 0 && (
            <tr>
              <td colSpan={columns.length + 1} className="empty">
                No records found
              </td>
            </tr>
          )}

          {data.map((row) => (
            <tr key={row.Id}>
              {columns.map((col) => (
                <td key={col.key}>{row[col.key]}</td>
              ))}

              {renderActions && (
                <td className="actions">{renderActions(row)}</td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
