import { useEffect, useState } from "react";
import { useMsal } from "@azure/msal-react";
import { getAccessToken } from "../../auth/authService";
import { getBilledMatrixForManager } from "../../services/sharePointService";
import { useUserContext } from "../../context/UserContext";

export default function ManagerBilledMatrix() {
  const { instance, accounts } = useMsal();
  const { userProfile } = useUserContext();

  const [rows, setRows] = useState([]);

  useEffect(() => {
    async function load() {
      const token = await getAccessToken(instance, accounts[0]);
      const data = await getBilledMatrixForManager(token, userProfile.email);
      setRows(data);
    }

    if (userProfile) load();
  }, [userProfile]);

  return (
    <div className="card">
      <h3>Billed Hours Summary</h3>

      <table className="data-table">
        <thead>
          <tr>
            <th>Employee</th>
            {rows[0]?.days.map((d) => (
              <th key={d}>{d}</th>
            ))}
          </tr>
        </thead>

        <tbody>
          {rows.map((r) => (
            <tr key={r.employee}>
              <td>{r.employee}</td>
              {r.values.map((v, i) => (
                <td key={i}>{v}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
