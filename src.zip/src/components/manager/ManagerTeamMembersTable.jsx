import { useUserContext } from "../../context/UserContext";
import DataTable from "../common/DataTable";
import { getManagerTeamMembers } from "../../services/sharePointService";

export default function ManagerTeamMembersTable() {
  const { employeeHierarchy, userProfile } = useUserContext();

  if (!employeeHierarchy || !userProfile) {
    return <p className="muted">Loading team...</p>;
  }

  const team = getManagerTeamMembers(employeeHierarchy, userProfile.email);

  const columns = [
    { key: "Name", label: "Employee" },
    { key: "Email", label: "Email" },
  ];

  const data = team.map((m) => ({
    Id: m.Employee.Id,
    Name: m.Employee.Title,
    Email: m.Employee.EMail,
  }));

  return (
    <div className="card">
      <h3>Team Members</h3>
      <DataTable columns={columns} data={data} />
    </div>
  );
}
