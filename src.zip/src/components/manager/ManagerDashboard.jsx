import ManagerTeamKpiCards from "./ManagerTeamKpiCards";
import ManagerTeamMembersTable from "./ManagerTeamMembersTable";
import ManagerApprovalTable from "./ManagerApprovalTable";
import ManagerUnderAllocatedTable from "./ManagerUnderAllocatedTable";
import ManagerMembersOnLeave from "./ManagerMembersOnLeave";
import ManagerTasksByClientDate from "./ManagerTasksByClientDate";
import ManagerBilledMatrix from "./ManagerBilledMatrix";

import "./managerDashboard.css";

export default function ManagerDashboard() {
  return (
    <>
      <h2>Manager Dashboard</h2>

      {/* KPI ROW */}
      <ManagerTeamKpiCards />

      {/* ROW 1 */}
      <div className="manager-grid">
        <ManagerTeamMembersTable />
        <ManagerApprovalTable />
      </div>

      {/* ROW 2 */}
      <div className="manager-grid">
        <ManagerUnderAllocatedTable />
        <ManagerMembersOnLeave />
      </div>

      {/* ROW 3 */}
      <div className="manager-grid">
        <ManagerTasksByClientDate />
        <div />
      </div>

      {/* FULL WIDTH */}
      <div className="manager-full">
        <ManagerBilledMatrix />
      </div>
    </>
  );
}
