import { useEffect, useState } from "react";
import { useMsal } from "@azure/msal-react";
import { getAccessToken } from "../../auth/authService";
import {
  getTeamTasksForDate,
  getManagerTeamMembers,
} from "../../services/sharePointService";
import { useUserContext } from "../../context/UserContext";
import DataTable from "../common/DataTable";

export default function ManagerUnderAllocatedTable() {
  const { instance, accounts } = useMsal();
  const { employeeHierarchy, userProfile } = useUserContext();
  const [rows, setRows] = useState([]);

  useEffect(() => {
    if (!employeeHierarchy || !userProfile) return;

    async function load() {
      const token = await getAccessToken(instance, accounts[0]);
      const team = getManagerTeamMembers(employeeHierarchy, userProfile.email);

      const today = new Date().toISOString().split("T")[0];

      const result = [];

      for (const m of team) {
        const tasks = await getTeamTasksForDate(token, today, [m.Employee.Id]);

        const total = tasks.reduce((s, t) => s + (t.EstimatedHours || 0), 0);

        if (total < 9) {
          result.push({
            Id: m.Employee.Id,
            Name: m.Employee.Title,
            Allocated: total,
          });
        }
      }

      setRows(result);
    }

    load();
  }, [employeeHierarchy, userProfile]);

  const columns = [
    { key: "Name", label: "Employee" },
    { key: "Allocated", label: "Allocated (hrs)" },
  ];

  return (
    <div className="card">
      <h3>Under-allocated Members</h3>
      <DataTable columns={columns} data={rows} />
    </div>
  );
}
