export const emptyLineChart = {
  labels: [],
  datasets: [
    {
      label: "No Data",
      data: [],
      borderColor: "#e5e7eb",
      backgroundColor: "#e5e7eb",
    },
  ],
};
